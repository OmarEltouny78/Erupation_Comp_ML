
from sklearn.mixture import GaussianMixture

import numpy as np
import pandas as pd
import glob
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso

#many train false
train = pd.read_csv("../input/predict-volcanic-eruptions-ingv-oe/train.csv")

#multiple files grouped using glob
train_frags = glob.glob("../input/predict-volcanic-eruptions-ingv-oe/train/*")

test_frags = glob.glob("../input/predict-volcanic-eruptions-ingv-oe/test/*")

check = pd.read_csv('../input/predict-volcanic-eruptions-ingv-oe/train/2037160701.csv')
#removing missing data getting observations and sensors in order to build features over them
sensors=set()
observations = set()
nan_columns = list()
missed_groups = list()
for_df = list()
#missing data in train
for item in train_frags:
    name = int(item.split('.')[-2].split('/')[-1])
    at_least_one_missed = 0
    frag = pd.read_csv(item)
    missed_group = list()
    missed_percents = list()
    for col in frag.columns:
        missed_percents.append(frag[col].isnull().sum() / len(frag))
        if pd.isnull(frag[col]).all() == True:
            at_least_one_missed = 1
            nan_columns.append(col)
            missed_group.append(col)
    if len(missed_group) > 0:
        missed_groups.append(missed_group)
    sensors.add(len(frag.columns))
    observations.add(len(frag))
    for_df.append([name, at_least_one_missed] + missed_percents)

print('Number of totaly missed sensors:', len(nan_columns))

absent_sensors = dict()
#sensors used to record data and checking for missing sensors
for item in nan_columns:
    if item in absent_sensors:
        absent_sensors[item] += 1
    else:
        absent_sensors[item] = 0
absent_groups = dict()

for item in missed_groups:
    if str(item) in absent_groups:
        absent_groups[str(item)] += 1
    else:
        absent_groups[str(item)] = 0
# created a data frame for missing data
for_df = pd.DataFrame(for_df, columns=['segment_id', 'has_missed_sensors', 'missed_percent_sensor1', 'missed_percent_sensor2', 'missed_percent_sensor3',
                                       'missed_percent_sensor4', 'missed_percent_sensor5', 'missed_percent_sensor6', 'missed_percent_sensor7',
                                       'missed_percent_sensor8', 'missed_percent_sensor9', 'missed_percent_sensor10'])

train = pd.merge(train, for_df)

sensors = set()
observations = set()
nan_columns = list()
missed_groups = list()
for_test_df = list()
#doing same process for test
for item in test_frags:
    name = int(item.split('.')[-2].split('/')[-1])
    at_least_one_missed = 0
    frag = pd.read_csv(item)
    missed_group = list()
    missed_percents = list()
    for col in frag.columns:
        missed_percents.append(frag[col].isnull().sum() / len(frag))
        if pd.isnull(frag[col]).all() == True:
            at_least_one_missed = 1
            nan_columns.append(col)
            missed_group.append(col)
    if len(missed_group) > 0:
        missed_groups.append(missed_group)
    sensors.add(len(frag.columns))
    observations.add(len(frag))
    for_test_df.append([name, at_least_one_missed] + missed_percents)

for_test_df = pd.DataFrame(for_test_df, columns=['segment_id', 'has_missed_sensors', 'missed_percent_sensor1', 'missed_percent_sensor2', 'missed_percent_sensor3',
                                       'missed_percent_sensor4', 'missed_percent_sensor5', 'missed_percent_sensor6', 'missed_percent_sensor7',
                                       'missed_percent_sensor8', 'missed_percent_sensor9', 'missed_percent_sensor10'])

print('Number of totaly missed sensors:', len(nan_columns))

absent_sensors = dict()

for item in nan_columns:
    if item in absent_sensors:
        absent_sensors[item] += 1
    else:
        absent_sensors[item] = 0
absent_groups = dict()

for item in missed_groups:
    if str(item) in absent_groups:
        absent_groups[str(item)] += 1
    else:
        absent_groups[str(item)] = 0
#features built for prediction
def build_features(signal, ts, sensor_id):
    X = pd.DataFrame()
    f = np.fft.fft(signal)
    f_real = np.real(f)
    X.loc[ts, f'{sensor_id}_sum']       = signal.sum()
    X.loc[ts, f'{sensor_id}_mean']      = signal.mean()
    X.loc[ts, f'{sensor_id}_std']       = signal.std()
    X.loc[ts, f'{sensor_id}_var']       = signal.var()
    X.loc[ts, f'{sensor_id}_max']       = signal.max()
    X.loc[ts, f'{sensor_id}_min']       = signal.min()
    X.loc[ts, f'{sensor_id}_skew']      = signal.skew()
    X.loc[ts, f'{sensor_id}_mad']       = signal.mad()
    X.loc[ts, f'{sensor_id}_kurtosis']  = signal.kurtosis()
    X.loc[ts, f'{sensor_id}_quantile99']= np.quantile(signal, 0.99)
    X.loc[ts, f'{sensor_id}_quantile95']= np.quantile(signal, 0.95)
    X.loc[ts, f'{sensor_id}_quantile85']= np.quantile(signal, 0.85)
    X.loc[ts, f'{sensor_id}_quantile75']= np.quantile(signal, 0.75)
    X.loc[ts, f'{sensor_id}_quantile55']= np.quantile(signal, 0.55)
    X.loc[ts, f'{sensor_id}_quantile45']= np.quantile(signal, 0.45)
    X.loc[ts, f'{sensor_id}_quantile25']= np.quantile(signal, 0.25)
    X.loc[ts, f'{sensor_id}_quantile15']= np.quantile(signal, 0.15)
    X.loc[ts, f'{sensor_id}_quantile05']= np.quantile(signal, 0.05)
    X.loc[ts, f'{sensor_id}_quantile01']= np.quantile(signal, 0.01)
    X.loc[ts, f'{sensor_id}_fft_real_mean']= f_real.mean()
    X.loc[ts, f'{sensor_id}_fft_real_std'] = f_real.std()
    X.loc[ts, f'{sensor_id}_fft_real_max'] = f_real.max()
    X.loc[ts, f'{sensor_id}_fft_real_min'] = f_real.min()

    return X

train_set = list()
j=0
for seg in train.segment_id:
    signals = pd.read_csv(f'/kaggle/input/predict-volcanic-eruptions-ingv-oe/train/{seg}.csv')
    train_row = []
    if j%500 == 0:
        print(j)
    for i in range(0, 10):
        sensor_id = f'sensor_{i+1}'
        train_row.append(build_features(signals[sensor_id].fillna(0), seg, sensor_id))
    train_row = pd.concat(train_row, axis=1)
    train_set.append(train_row)
    j+=1
train_set = pd.concat(train_set)

train_set = train_set.reset_index()

train_set = train_set.rename(columns={'index': 'segment_id'})

train_set = pd.merge(train_set, train, on='segment_id')

drop_cols = []
#columns that are useless for our prediction
for col in train_set.columns:
    if col == 'segment_id':
        continue
    if abs(train_set[col].corr(train_set['time_to_eruption'])) < 0.01:
        drop_cols.append(col)

not_to_drop_cols = []

for col1 in train_set.columns:
    for col2 in train_set.columns:
        if col1 == col2:
            continue
        if col1 == 'segment_id' or col2 == 'segment_id':
            continue
        if col1 == 'time_to_eruption' or col2 == 'time_to_eruption':
            continue
        if abs(train_set[col1].corr(train_set[col2])) > 0.98:
            if col2 not in drop_cols and col1 not in not_to_drop_cols:
                drop_cols.append(col2)
                not_to_drop_cols.append(col1)

train = train_set.drop(['segment_id', 'time_to_eruption'], axis=1)
y = train_set['time_to_eruption']

reduced_y = y.copy()
reduced_train = train.copy()
reduced_train = reduced_train.drop(drop_cols, axis=1)

train, val, y, y_val = train_test_split(train, y, random_state=666, test_size=0.2, shuffle=True)
reduced_train, reduced_val, reduced_y, reduced_y_val = train_test_split(reduced_train, reduced_y, random_state=666, test_size=0.2, shuffle=True)

#Mixture model
clm=GaussianMixture()
clm.fit(train, y)
preds = clm.predict(val)
clm.score(y_val,preds)